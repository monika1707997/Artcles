const express = require('express');
const mongoose = require('mongoose');
const exphbs = require('express-handlebars');
const app = express();

//mongodb urls here
const RemoteUrl = "mongodb+srv://monika:monika123@cluster0-dlr0s.mongodb.net/test?retryWrites=true&w=majority";
const LocalUrl = "mongodb://localhost:27017/cappost";

//connect to database
mongoose.connect(RemoteUrl, {useNewUrlParser:true},(err)=>{
    if(err)throw err;
    else console.log('database created');
})

//static
app.use(express.static(__dirname + '/public'));

// app.get('*', (req,res)=>{
//     res.send("<h1>Hello Monika</h1>");
// })    to show 1 to 2 lines of html


app.engine('handlebars', exphbs());
app.set('view engine','handlebars');

app.get('',(req,res)=>{
    res.render('./index.handlebars');
});
app.get('/login', (req,res)=>{
    res.render('./login.handlebars');
});
app.get('/addpost',(req,res)=>{
    res.render('./posts/addpost.handlebars')
});
app.get('**', (req,res)=>{
    res.render('./pagenotfound.handlebars');
});



const port = process.env.PORT || 3000;
app.listen(3000, err=>{
    if(err)throw err;
    else
        console.log(`App is listening on port ${port} ! `);
    
});